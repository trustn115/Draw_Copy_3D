﻿using UnityEngine;

namespace Boxophobic.StyledGUI
{
    public class StyledTexturePreview : PropertyAttribute
    {
    }
}

