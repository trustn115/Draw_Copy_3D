﻿using UnityEngine;

namespace Boxophobic.StyledGUI
{
    public class StyledCategory : PropertyAttribute
    {
        public string category;

        public StyledCategory(string category)
        {
            this.category = category;
        }
    }
}

