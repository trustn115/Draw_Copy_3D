using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _Draw_Copy._Scripts.GameplayRelated
{ 
    public class Shape : MonoBehaviour
    {
        public List<Transform> points;
    }   
}
